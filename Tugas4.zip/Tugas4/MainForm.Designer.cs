﻿/*
 * Created by SharpDevelop.
 * User: Amru khair
 * Date: 3/2/2022
 * Time: 9:29 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
namespace Tugas4
{
	partial class MainForm
	{
		/// <summary>
		/// Designer variable used to keep track of non-visual components.
		/// </summary>
		private System.ComponentModel.IContainer components = null;
		
		/// <summary>
		/// Disposes resources used by the form.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing) {
				if (components != null) {
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}
		
		/// <summary>
		/// This method is required for Windows Forms designer support.
		/// Do not change the method contents inside the source code editor. The Forms designer might
		/// not be able to load this method if it was changed manually.
		/// </summary>
		private void InitializeComponent()
		{
			this.label1 = new System.Windows.Forms.Label();
			this.txt_Nama = new System.Windows.Forms.TextBox();
			this.txt_NIM = new System.Windows.Forms.TextBox();
			this.txt_Kelas = new System.Windows.Forms.TextBox();
			this.txt_Matkul = new System.Windows.Forms.TextBox();
			this.label2 = new System.Windows.Forms.Label();
			this.label3 = new System.Windows.Forms.Label();
			this.label4 = new System.Windows.Forms.Label();
			this.btn_show = new System.Windows.Forms.Button();
			this.label5 = new System.Windows.Forms.Label();
			this.SuspendLayout();
			// 
			// label1
			// 
			this.label1.Font = new System.Drawing.Font("Bookman Old Style", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.label1.Location = new System.Drawing.Point(12, 78);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(279, 23);
			this.label1.TabIndex = 0;
			this.label1.Text = "Masukkan Nama Anda";
			// 
			// txt_Nama
			// 
			this.txt_Nama.Font = new System.Drawing.Font("Bookman Old Style", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.txt_Nama.Location = new System.Drawing.Point(299, 75);
			this.txt_Nama.Name = "txt_Nama";
			this.txt_Nama.Size = new System.Drawing.Size(304, 31);
			this.txt_Nama.TabIndex = 1;
			// 
			// txt_NIM
			// 
			this.txt_NIM.Font = new System.Drawing.Font("Bookman Old Style", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.txt_NIM.Location = new System.Drawing.Point(299, 112);
			this.txt_NIM.Name = "txt_NIM";
			this.txt_NIM.Size = new System.Drawing.Size(304, 31);
			this.txt_NIM.TabIndex = 2;
			// 
			// txt_Kelas
			// 
			this.txt_Kelas.Font = new System.Drawing.Font("Bookman Old Style", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.txt_Kelas.Location = new System.Drawing.Point(299, 149);
			this.txt_Kelas.Name = "txt_Kelas";
			this.txt_Kelas.Size = new System.Drawing.Size(304, 31);
			this.txt_Kelas.TabIndex = 3;
			// 
			// txt_Matkul
			// 
			this.txt_Matkul.Font = new System.Drawing.Font("Bookman Old Style", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.txt_Matkul.Location = new System.Drawing.Point(299, 186);
			this.txt_Matkul.Name = "txt_Matkul";
			this.txt_Matkul.Size = new System.Drawing.Size(304, 31);
			this.txt_Matkul.TabIndex = 4;
			// 
			// label2
			// 
			this.label2.Font = new System.Drawing.Font("Bookman Old Style", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label2.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.label2.Location = new System.Drawing.Point(12, 115);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(279, 23);
			this.label2.TabIndex = 5;
			this.label2.Text = "Masukkan NIM Anda";
			// 
			// label3
			// 
			this.label3.Font = new System.Drawing.Font("Bookman Old Style", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label3.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.label3.Location = new System.Drawing.Point(12, 152);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(279, 23);
			this.label3.TabIndex = 6;
			this.label3.Text = "Masukkan Kelas Anda";
			// 
			// label4
			// 
			this.label4.Font = new System.Drawing.Font("Bookman Old Style", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label4.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.label4.Location = new System.Drawing.Point(12, 189);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(279, 23);
			this.label4.TabIndex = 7;
			this.label4.Text = "Mata Kuliah";
			// 
			// btn_show
			// 
			this.btn_show.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btn_show.Location = new System.Drawing.Point(299, 234);
			this.btn_show.Name = "btn_show";
			this.btn_show.Size = new System.Drawing.Size(304, 38);
			this.btn_show.TabIndex = 8;
			this.btn_show.Text = "Tampilkan Data";
			this.btn_show.UseVisualStyleBackColor = true;
			this.btn_show.Click += new System.EventHandler(this.Btn_showClick);
			// 
			// label5
			// 
			this.label5.Font = new System.Drawing.Font("ROG Fonts", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label5.Location = new System.Drawing.Point(12, 13);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(591, 49);
			this.label5.TabIndex = 9;
			this.label5.Text = "DATA MAHASISWA";
			this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// MainForm
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(615, 284);
			this.Controls.Add(this.label5);
			this.Controls.Add(this.btn_show);
			this.Controls.Add(this.label4);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.txt_Matkul);
			this.Controls.Add(this.txt_Kelas);
			this.Controls.Add(this.txt_NIM);
			this.Controls.Add(this.txt_Nama);
			this.Controls.Add(this.label1);
			this.Name = "MainForm";
			this.Text = "Tugas 4";
			this.ResumeLayout(false);
			this.PerformLayout();
		}
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.Button btn_show;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.TextBox txt_Matkul;
		private System.Windows.Forms.TextBox txt_Kelas;
		private System.Windows.Forms.TextBox txt_NIM;
		private System.Windows.Forms.TextBox txt_Nama;
		private System.Windows.Forms.Label label1;
	}
}
