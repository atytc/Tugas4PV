﻿/*
 * Created by SharpDevelop.
 * User: Amru khair
 * Date: 3/2/2022
 * Time: 9:29 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace Tugas4
{
	/// <summary>
	/// Description of MainForm.
	/// </summary>
	public partial class MainForm : Form
	{
		public MainForm()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			
			//
			// TODO: Add constructor code after the InitializeComponent() call.
			//
		}
		
		void Btn_showClick(object sender, EventArgs e)
		{
			MessageBox.Show("Hallo, Selamat Datang!" + Environment.NewLine +
							"Nama		: " + this.txt_Nama.Text + Environment.NewLine +
							"NIM		: " + this.txt_NIM.Text + Environment.NewLine +
							"Kelas		: " + this.txt_Kelas.Text + Environment.NewLine +
							"Mata Kuliah	: " + this.txt_Matkul.Text);
		}
	}
}
